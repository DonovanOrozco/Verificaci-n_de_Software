const express = require('express');
const { getInfo, getProducts, getContact, logRequest } = require('../controllers/businessController');

const router = express.Router();

/**
 * @swagger
 * /business/info:
 *   get:
 *     summary: Obtener información del negocio
 *     description: Devuelve información general del negocio.
 *     responses:
 *       200:
 *         description: Información obtenida con éxito.
 */
router.get('/info', logRequest, getInfo);

/**
 * @swagger
 * /business/products:
 *   get:
 *     summary: Obtener lista de productos
 *     description: Devuelve la lista de productos disponibles.
 *     responses:
 *       200:
 *         description: Lista de productos obtenida con éxito.
 */
router.get('/products', logRequest, getProducts);

/**
 * @swagger
 * /business/contact:
 *   post:
 *     summary: Enviar información de contacto
 *     description: Permite enviar información de contacto al negocio.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               nombre:
 *                 type: string
 *                 description: Nombre del usuario
 *               mensaje:
 *                 type: string
 *                 description: Mensaje del usuario
 *     responses:
 *       201:
 *         description: Contacto recibido con éxito.
 *       400:
 *         description: Solicitud inválida.
 */
router.post('/contact', logRequest, getContact);

module.exports = router;
