const fs = require('fs');
const moment = require('moment');
const logToFile = (data) => {
    const logFilePath = './logs/api.log';
    const logEntry = `${moment().format('YYYY-MM-DD HH:mm:ss')} - ${JSON.stringify(data)}\n`;
    fs.appendFileSync(logFilePath, logEntry);
};
const logRequest = (req, res, next) => {
    const logData = {
        tiempo: moment().format('YYYY-MM-DD HH:mm:ss'),
        metodo: req.method,
        endpoint: req.originalUrl,
        ip: req.ip
    };
    logToFile(logData);
    next();
};
const getInfo = (req, res) => {
    res.status(200).json({
        estado: 200,
        mensaje: "Información general del negocio",
        negocio: "Mi Tienda"
    });
};
const getProducts = (req, res) => {
    const products = [
        { id: 1, description: "leche", completed: true },
        { id: 2, description: "pan", completed: true }
    ];
    res.status(200).json({
        estado: 200,
        mensaje: "Lista de productos",
        productos: products
    });
};
const getContact = (req, res) => {
    const { nombre, mensaje } = req.body;

    if (!nombre || !mensaje) {
        return res.status(400).json({
            estado: 400,
            mensaje: "Faltan parámetros obligatorios"
        });
    }

    res.status(201).json({
        estado: 201,
        mensaje: "Contacto recibido",
        contacto: { nombre, mensaje }
    });
};

module.exports = { getInfo, getProducts, getContact, logRequest };
